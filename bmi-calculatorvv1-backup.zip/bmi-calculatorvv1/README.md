# ⚖️ ️️bmi-calculator

A simple body mass index calculator.
